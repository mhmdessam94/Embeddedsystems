

#ifndef  TIMER_INTERFACE_H_
#define  TIMER_INTERFACE_H_

/************ Timer Number ************/

#define TIMER_0						1
#define TIMER_1A					2
#define TIMER_1B					3
#define TIMER_2						4


/************ Timers Interrupt sources ************/

#define TIMER0_OVERFLOW_INT			0
#define TIMER0_OUTPUT_COM_INT		1

#define TIMER1_OVERFLOW_INT			2
#define TIMER1_OUTPUT_COM_A_INT		3
#define TIMER1_OUTPUT_COM_B_INT		4
#define TIMER1_ICU_INT				5

#define TIMER2_OVERFLOW_INT			6
#define TIMER2_OUTPUT_COM_INT		7

/************ ICU Configuration ************/

#define ICU_RISING_EDGE				1
#define ICU_FALLING_EDGE			2

#define ICU_INT_ENABLE				1
#define ICU_INT_DISABLE				2

/************ Waveform Generation Selection ************/

#define NORMAL						0
#define PHASE_CORRECT				1
#define CTC							2
#define FAST_PWM					3

/************ Output Compare Mode ************/

#define DISCONNECT					0
#define TOGGLE						1
#define CLEAR						2
#define SET							3

#define NON_INVERTING_PWM			2
#define INVERTING_PWM				3

/************ Clock Scaler Selection ************/

#define TIMER_DIV_BY_1				1
#define TIMER_DIV_BY_8				2
#define TIMER_DIV_BY_64				3
#define TIMER_DIV_BY_256			4
#define TIMER_DIV_BY_1024			5
#define TIMER_EXT_CLK_FALLING_EDGE	6
#define TIMER_EXT_CLK_RISING_EDGE	7

#define TIMER1_CHANNEL_A			1
#define TIMER1_CHANNEL_B			2

uint8 TIMER0_uint8Init(uint8 Copy_uint8WaveMode , uint8 Copy_uint8CompereMode ,uint8 Copy_uint8Prescaler);

uint8 TIMER1_uint8Init(uint8 Copy_uint8Channel , uint8 Copy_uint8WaveMode , uint8 Copy_uint8CompereMode ,uint8 Copy_uint8Prescaler);

uint8 TIMER2_uint8Init(uint8 Copy_uint8WaveMode , uint8 Copy_uint8CompereMode ,uint8 Copy_uint8Prescaler);

void TIMER0_voidSetCompMatchVal(uint8 Copy_uint8Value);


void TIMER1_voidSetICR(uint16 Copy_uint16Top);

void TIMER1_voidSetChannelACompMatchVal(uint16 Copy_uint16Value);

void TIMER1_voidSetTimerValue(uint16 Copy_uint16Value);

uint16 TIMER1_uint16ReadTimerValue(void);

void TIMER2_voidSetCompMatchVal(uint8 Copy_uint8Value);

void ICU_voidInit(void);

uint8 ICU_uint8SetTiggerEdge(uint8 Copy_uint8Edge);

uint8 ICU_uint8EnableControl(uint8 Copy_uint8Enable);

uint16 ICU_uint16ReadingICU(void);

uint8 TIMER_uint8SetCallBack(uint8 Copy_uint8INT_ID,void (*Copy_pvCallBackFunc)(void));


void PWM_voidSetPWM(uint8 Copy_uint8TimerNum,uint16 Copy_uint16Duration) ;

void WDT_voidSleep(u8 Copy_u8SleepTime);
void WDT_voidEnable(void);
void WDT_voidDisable(void);

#endif
