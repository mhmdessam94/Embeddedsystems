


#include "STD_TYPES.h"
#include "BIT_MATH.h"

#include "TIMER_register.h"
#include "TIMER_config.h"
#include "TIMER_private.h"
#include "TIMER_interface.h"

static void	(* TIMER_pvCallBackFunc[8])(void) = {NULL};


uint8 TIMER0_uint8Init(uint8 Copy_uint8WaveMode , uint8 Copy_uint8CompereMode ,uint8 Copy_uint8Prescaler)
{
	uint8 Local_uint8ErrorState = OK;

	/*Set waveform generation mode*/
	switch(Copy_uint8WaveMode)
	{
	case NORMAL :
		CLR_BIT(TCCR0,TCCR0_WGM00);
		CLR_BIT(TCCR0,TCCR0_WGM01);

		/*Enable overflow interrupt*/
		SET_BIT(TIMSK,TIMSK_TOIE0);

		break;

	case PHASE_CORRECT :
		SET_BIT(TCCR0,TCCR0_WGM00);
		CLR_BIT(TCCR0,TCCR0_WGM01);
		break;

	case CTC :
		CLR_BIT(TCCR0,TCCR0_WGM00);
		SET_BIT(TCCR0,TCCR0_WGM01);

		/*Enable output Compare interrupt*/
		SET_BIT(TIMSK,TIMSK_OCIE0);
		break;

	case FAST_PWM :
		SET_BIT(TCCR0,TCCR0_WGM00);
		SET_BIT(TCCR0,TCCR0_WGM01);
		break;

	default : Local_uint8ErrorState = NOK;
	}

	/*Set Output compare mode*/
	TCCR0 &= TIMER0_COM_MASK;
	TCCR0 |= Copy_uint8CompereMode << 4;

	/*Set prescaler */
	TCCR0 &= TIMER_PRESCALER_MASK;
	TCCR0 |= Copy_uint8Prescaler;

	return Local_uint8ErrorState;
}

uint8 TIMER1_uint8Init(uint8 Copy_uint8Channel , uint8 Copy_uint8WaveMode , uint8 Copy_uint8CompereMode ,uint8 Copy_uint8Prescaler)
{
	uint8 Local_uint8Errorstate = OK;

	/*check timer channel*/

	if(Copy_uint8Channel == TIMER1_CHANNEL_A)
	{
		/*Set output compare mode*/
		TCCR1A &= TIMER1_COM_MASK_A;
		TCCR1A |= Copy_uint8CompereMode << 6;

		/*Set Wave generation mode*/
		switch(Copy_uint8WaveMode)
		{
		case NORMAL :
			CLR_BIT(TCCR1A,TCCR1A_WGM10);
			CLR_BIT(TCCR1A,TCCR1A_WGM11);

			/*Enable overflow interrupt*/
			SET_BIT(TIMSK,TIMSK_TOIE1);

			break;

		case CTC :
			CLR_BIT(TCCR1A,TCCR1A_WGM10);
			CLR_BIT(TCCR1A,TCCR1A_WGM11);

			/*Enable output Compare interrupt*/
			SET_BIT(TIMSK,TIMSK_OCIE1A);

			break;

		case PHASE_CORRECT :
			CLR_BIT(TCCR1A,TCCR1A_WGM10);
			SET_BIT(TCCR1A,TCCR1A_WGM11);
			break;

		case FAST_PWM :
			CLR_BIT(TCCR1A,TCCR1A_WGM10);
			SET_BIT(TCCR1A,TCCR1A_WGM11);
			break;

		default : Local_uint8Errorstate = NOK;

		}
	}

	else if (Copy_uint8Channel == TIMER1_CHANNEL_B)
	{
		/*Set output compare mode*/
		TCCR1B &= TIMER1_COM_MASK_B;
		TCCR1B |= Copy_uint8CompereMode << 4;

		/*Set Wave generation mode*/
		switch(Copy_uint8WaveMode)
		{
		case NORMAL :
			CLR_BIT(TCCR1B,TCCR1B_WGM12);
			CLR_BIT(TCCR1B,TCCR1B_WGM13);

			/*Enable overflow interrupt*/
			SET_BIT(TIMSK,TIMSK_TOIE1);

			break;

		case CTC :
			SET_BIT(TCCR1B,TCCR1B_WGM12);
			CLR_BIT(TCCR1B,TCCR1B_WGM13);

			/*Enable output Compare interrupt*/
			SET_BIT(TIMSK,TIMSK_OCIE1B);
			break;

		case PHASE_CORRECT :
			CLR_BIT(TCCR1B,TCCR1B_WGM12);
			SET_BIT(TCCR1B,TCCR1B_WGM13);
			break;

		case FAST_PWM :
			SET_BIT(TCCR1B,TCCR1B_WGM12);
			SET_BIT(TCCR1B,TCCR1B_WGM13);
			break;

		default : Local_uint8Errorstate = NOK;

		}
	}

	else
	{
		Local_uint8Errorstate = NOK;
	}

	/*Set prescalre*/
	TCCR1B &= TIMER_PRESCALER_MASK;
	TCCR1B |= Copy_uint8Prescaler;

	return Local_uint8Errorstate;
}


uint8 TIMER2_uint8Init(uint8 Copy_uint8WaveMode , uint8 Copy_uint8CompereMode ,uint8 Copy_uint8Prescaler)
{
	uint8 Local_uint8ErrorState = OK;

	/*Set waveform generation mode*/
	switch(Copy_uint8WaveMode)
	{
	case NORMAL :
		CLR_BIT(TCCR2,TCCR2_WGM20);
		CLR_BIT(TCCR2,TCCR2_WGM21);

		/*Enable overflow interrupt*/
		SET_BIT(TIMSK,TIMSK_TOIE2);
		break;

	case PHASE_CORRECT :
		SET_BIT(TCCR2,TCCR2_WGM20);
		CLR_BIT(TCCR2,TCCR2_WGM21);
		break;

	case CTC :
		CLR_BIT(TCCR2,TCCR2_WGM20);
		SET_BIT(TCCR2,TCCR2_WGM21);

		/*Enable output Compare interrupt*/
		SET_BIT(TIMSK,TIMSK_OCIE2);
		break;

	case FAST_PWM :
		SET_BIT(TCCR2,TCCR2_WGM20);
		SET_BIT(TCCR2,TCCR2_WGM21);

		break;

	default : Local_uint8ErrorState = NOK;
	}

	/*Set Output compare mode*/
	TCCR2 &= TIMER2_COM_MASK;
	TCCR2 |= Copy_uint8CompereMode << 4;

	/*Set prescaler */
	TCCR2 &= TIMER_PRESCALER_MASK;
	TCCR2 |= Copy_uint8Prescaler;

	return Local_uint8ErrorState;
}

void TIMER0_voidSetCompMatchVal(uint8 Copy_uint8Value)
{
	OCR0 = Copy_uint8Value;
}

void TIMER1_voidSetICR(uint16 Copy_uint16Top)
{
	ICR1 = Copy_uint16Top;
}

void TIMER1_voidSetChannelACompMatchVal(uint16 Copy_uint16Value)
{
	OCR1A = Copy_uint16Value;
}

void TIMER1_voidSetTimerValue(uint16 Copy_uint16Value)
{
	TCNT1 = Copy_uint16Value;
}

uint16 TIMER1_uint16ReadTimerValue(void)
{
	return TCNT1;
}

void TIMER2_voidSetCompMatchVal(uint8 Copy_uint8Value)
{
	OCR2 = Copy_uint8Value;
}
void ICU_voidInit(void)
{

	/*Select triggered edge : rising edge*/
	SET_BIT(TCCR1B,TCCR1B_ICES);

	/*Enable ICU interrupt*/
	SET_BIT(TIMSK,TIMSK_TICIE1);
}

uint8 ICU_uint8SetTiggerEdge(uint8 Copy_uint8Edge)
{
	uint8 Local_uint8ErrorState = OK;

	if(Copy_uint8Edge == ICU_RISING_EDGE)
	{
		SET_BIT(TCCR1B,TCCR1B_ICES);
	}
	else if (Copy_uint8Edge == ICU_FALLING_EDGE)
	{
		CLR_BIT(TCCR1B,TCCR1B_ICES);
	}
	else
	{
		Local_uint8ErrorState = NOK;
	}
	return Local_uint8ErrorState;
}

uint8 ICU_uint8EnableControl(uint8 Copy_uint8Enable)
{
	uint8 Local_uint8ErrorState = OK;

	if(Copy_uint8Enable == ICU_INT_ENABLE)
	{
		SET_BIT(TIMSK,TIMSK_TICIE1);
	}
	else if(Copy_uint8Enable == ICU_INT_DISABLE)
	{
		CLR_BIT(TIMSK,TIMSK_TICIE1);
	}
	else
	{
		Local_uint8ErrorState = NOK;
	}
	return Local_uint8ErrorState;
}

uint16 ICU_uint16ReadingICU(void)
{
	return ICR1;
}

uint8 TIMER_uint8SetCallBack(uint8 Copy_uint8INT_ID,void (*Copy_pvCallBackFunc)(void))
{
	uint8 Local_uint8ErrorState = OK;

	if(Copy_pvCallBackFunc != NULL)
	{
		TIMER_pvCallBackFunc[Copy_uint8INT_ID] = Copy_pvCallBackFunc;
	}
	else
	{
		Local_uint8ErrorState = NULL_POINTER;
	}

	return Local_uint8ErrorState;
}


void PWM_voidSetPWM(uint8 Copy_uint8TimerNum,uint16 Copy_uint16Duration)
{
	switch(Copy_uint8TimerNum)
	{
	case TIMER_0 	: OCR0  = Copy_uint16Duration;break;
	case TIMER_1A 	: OCR1A = Copy_uint16Duration;break;
	case TIMER_1B 	: OCR1B = Copy_uint16Duration;break;
	case TIMER_2 	: OCR2  = Copy_uint16Duration;break;

	}
}

void WDT_voidSleep(u8 Copy_u8SleepTime)
{
	/*Clear prescaler bits*/
	WDTCR &= 0b11111000;

	/*Set required prescaler */
	WDTCR |=  Copy_u8SleepTime;
}
void WDT_voidEnable(void)
{
	/*Enable WDT*/
	SET_BIT(WDTCR,WDTCR_WDE);
}
void WDT_voidDisable(void)
{
	/*Set WDE and WDTOE*/
	WDTCR |= 0b00011000;

	/*Clear WDE bit*/
	WDTCR = 0;

}
void __vector_4 (void) __attribute__ ((signal));
void __vector_4 (void)
{
	if(TIMER_pvCallBackFunc[TIMER2_OUTPUT_COM_INT] != NULL)
	{
		TIMER_pvCallBackFunc[TIMER2_OUTPUT_COM_INT]();
	}
}

void __vector_5 (void) __attribute__ ((signal));
void __vector_5 (void)
{
	if(TIMER_pvCallBackFunc[TIMER2_OVERFLOW_INT] != NULL)
	{
		TIMER_pvCallBackFunc[TIMER2_OVERFLOW_INT]();
	}
}

void __vector_6 (void) __attribute__ ((signal));
void __vector_6 (void)
{
	if(TIMER_pvCallBackFunc[TIMER1_ICU_INT] != NULL)
	{
		TIMER_pvCallBackFunc[TIMER1_ICU_INT]();
	}
}

void __vector_7 (void) __attribute__ ((signal));
void __vector_7 (void)
{
	if(TIMER_pvCallBackFunc[TIMER1_OUTPUT_COM_A_INT] != NULL)
	{
		TIMER_pvCallBackFunc[TIMER1_OUTPUT_COM_A_INT]();
	}
}

void __vector_8 (void) __attribute__ ((signal));
void __vector_8 (void)
{
	if(TIMER_pvCallBackFunc[TIMER1_OUTPUT_COM_B_INT] != NULL)
	{
		TIMER_pvCallBackFunc[TIMER1_OUTPUT_COM_B_INT]();
	}
}

void __vector_9 (void) __attribute__ ((signal));
void __vector_9 (void)
{
	if(TIMER_pvCallBackFunc[TIMER1_OVERFLOW_INT] != NULL)
	{
		TIMER_pvCallBackFunc[TIMER1_OVERFLOW_INT]();
	}
}

void __vector_10 (void)	__attribute__((signal));
void __vector_10 (void)
{
	if(TIMER_pvCallBackFunc[TIMER0_OUTPUT_COM_INT] != NULL)
	{
		TIMER_pvCallBackFunc[TIMER0_OUTPUT_COM_INT]();
	}
}

void __vector_11 (void)	__attribute__((signal));
void __vector_11 (void)
{
	if(TIMER_pvCallBackFunc[TIMER0_OVERFLOW_INT] != NULL)
	{
		TIMER_pvCallBackFunc[TIMER0_OVERFLOW_INT]();
	}
}

