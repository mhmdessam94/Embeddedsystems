

#ifndef UART_INTER_H_
#define UART_INTER_H_




/**
 * @brief this function to initIate UART
 */
void UART_voidInit(void);

/**
 * @brief this function to send data using UART
 * @param Copy_uint8Data
 */
void UART_voidTransmitData(uint8 Copy_uint8Data);

/**
 * @brief this function to Receive data using UART
 * @return Local_uint8Data
 */
uint8 UART_uint8ReceiveData(void);



#endif /* UART_INTER_H_ */
