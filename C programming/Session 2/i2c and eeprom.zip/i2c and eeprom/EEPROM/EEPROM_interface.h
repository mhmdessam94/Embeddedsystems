

#ifndef EEPROM_INTERFACE_H_
#define EEPROM_INTERFACE_H_

void EEPROM_voidSendDataByte(uint16 Copy_uint16LocationAddress, uint8 Copy_uint8DataByte);

uint8 EEPROM_uint8ReadDataByte(uint16 Copy_uint16LocationAddress);

#endif
