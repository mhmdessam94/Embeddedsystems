#include "STD_TYPES.h"
#include "TWI_interface.h"
#include "PORT_interface.h"
#include "DIO_interface.h"

#include "EEPROM_interface.h"

void main(void)
{
	uint8 Local_uint8ReceivedData;
	PORT_voidInit();		/*Define PORTA as output*/

	TWI_voidInitMaster(0);

	EEPROM_voidSendDataByte(0, 0x55);

	Local_uint8ReceivedData = EEPROM_uint8ReadDataByte(0);

	DIO_uint8SetPortValue(DIO_uint8PORTA,Local_uint8ReceivedData);

	while(1)
	{

	}
}
