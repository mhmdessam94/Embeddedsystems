

#ifndef  SPI_INTERFACE_H_
#define  SPI_INTERFACE_H_

void SPI_voidMasterInit(void);

void SPI_voidSlaveInit(void);

uint8 SPI_Transceive(uint8 Copy_uint8Data);

#endif
